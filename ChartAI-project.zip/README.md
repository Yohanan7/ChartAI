# ChartAI — Analyse Graphique

Projet Android Studio Kotlin sans AndroidX et sans dépendance externe.

## Configuration

- package/applicationId : `com.example.chartai`
- minSdk : 29
- targetSdk : 34
- compileSdk : 34
- AGP : 8.5.2
- Kotlin : 1.9.24
- Java : 17
- Gradle : 8.7

## Compilation

Ouvrir le dossier dans Android Studio, synchroniser Gradle, puis :

**Build > Build APK(s)**

APK debug :

`app/build/outputs/apk/debug/app-debug.apk`

## API

L'application appelle :

`https://api.anthropic.com/v1/messages`

Le modèle est défini dans `OverlayService.kt` :

`claude-sonnet-5-5`

Une clé API Anthropic valide est nécessaire. La facturation API Anthropic est distincte d'un abonnement Claude.

## Permissions

L'application demande :
- Internet
- Affichage par-dessus les autres applications
- Service au premier plan de type MediaProjection
- Notifications sur Android 13+
- Autorisation de capture d'écran Android

## Avertissement

Le signal ACHAT/VENTE/ATTENTE est une aide à l'analyse graphique et non un conseil financier. Il n'y a aucune garantie de résultat.
