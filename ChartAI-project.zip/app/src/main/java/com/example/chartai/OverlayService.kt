package com.example.chartai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"

        private const val CHANNEL_ID = "chart_ai_capture"
        private const val NOTIFICATION_ID = 5001

        // Valeur demandée pour ce projet.
        private const val MODEL = "claude-sonnet-5-5"

        private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
        private const val MAX_TOKENS = 400
    }

    private lateinit var windowManager: WindowManager
    private lateinit var projectionManager: MediaProjectionManager

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    @Volatile
    private var latestBitmap: Bitmap? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val analysisRunning = AtomicBoolean(false)

    private lateinit var panel: LinearLayout
    private lateinit var signalText: TextView
    private lateinit var explanationText: TextView

    private var panelParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        createOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }

        if (resultCode != -1 && data != null && mediaProjection == null) {
            startCapture(resultCode, data)
        }

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Capture Analyse Graphique",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Capture d'écran nécessaire au panneau d'analyse."
            }

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundForCapture() {
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Analyse Graphique")
                .setContentText("Capture d'écran active pour analyser le graphique.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Analyse Graphique")
                .setContentText("Capture d'écran active.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        startForegroundForCapture()

        try {
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            mediaProjection?.registerCallback(
                object : MediaProjection.Callback() {
                    override fun onStop() {
                        mainHandler.post { stopSelf() }
                    }
                },
                mainHandler
            )

            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            imageReader = ImageReader.newInstance(
                width,
                height,
                PixelFormat.RGBA_8888,
                2
            )

            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    latestBitmap = imageToBitmap(image)
                } catch (_: Throwable) {
                    // Une image ponctuellement invalide ne doit pas arrêter la capture.
                } finally {
                    image.close()
                }
            }, mainHandler)

            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "ChartAI-Capture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
        } catch (t: Throwable) {
            showError("Impossible de démarrer la capture : ${t.message ?: "erreur inconnue"}")
            stopSelf()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height

        val rowPaddingPixels =
            ((rowStride - pixelStride * width).coerceAtLeast(0) / pixelStride)

        val paddedWidth = width + rowPaddingPixels
        val raw = Bitmap.createBitmap(
            paddedWidth,
            height,
            Bitmap.Config.ARGB_8888
        )
        buffer.rewind()
        raw.copyPixelsFromBuffer(buffer)

        return if (paddedWidth == width) {
            raw
        } else {
            val cropped = Bitmap.createBitmap(raw, 0, 0, width, height)
            raw.recycle()
            cropped
        }
    }

    private fun createOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(Color.argb(235, 25, 25, 25))
        }

        signalText = TextView(this).apply {
            text = "ATTENTE"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(10, 8, 10, 12)
        }

        explanationText = TextView(this).apply {
            text = "Appuyez sur Analyser."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(10, 4, 10, 12)
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val analyzeButton = Button(this).apply {
            text = "Analyser"
            setOnClickListener { analyzeCurrentScreen() }
        }

        val closeButton = Button(this).apply {
            text = "X"
            setOnClickListener { stopSelf() }
        }

        buttons.addView(
            analyzeButton,
            LinearLayout.LayoutParams(0, 52, 1f)
        )
        buttons.addView(
            closeButton,
            LinearLayout.LayoutParams(90, 52)
        )

        panel.addView(
            signalText,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        panel.addView(
            explanationText,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        panel.addView(
            buttons,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 120
        }

        panelParams = params
        windowManager.addView(panel, params)

        signalText.setOnTouchListener(DragTouchListener())
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var initialX = 0
        private var initialY = 0

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val params = panelParams ?: return false

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    initialX = params.x
                    initialY = params.y
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - downX).roundToInt()
                    params.y = initialY + (event.rawY - downY).roundToInt()
                    windowManager.updateViewLayout(panel, params)
                    return true
                }
            }

            return true
        }
    }

    private fun analyzeCurrentScreen() {
        if (!analysisRunning.compareAndSet(false, true)) return

        signalText.text = "ANALYSE…"
        explanationText.text = "Lecture du graphique en cours."

        panel.visibility = View.INVISIBLE

        mainHandler.postDelayed({
            val snapshot = latestBitmap?.let { bitmap ->
                bitmap.copy(Bitmap.Config.ARGB_8888, false)
            }

            panel.visibility = View.VISIBLE

            if (snapshot == null) {
                analysisRunning.set(false)
                signalText.text = "ATTENTE"
                explanationText.text = "Aucune image disponible."
                return@postDelayed
            }

            val apiKey = getSharedPreferences("chart_ai_prefs", MODE_PRIVATE)
                .getString("anthropic_api_key", "")
                .orEmpty()

            if (apiKey.isBlank()) {
                snapshot.recycle()
                analysisRunning.set(false)
                signalText.text = "ATTENTE"
                explanationText.text = "Clé API absente."
                return@postDelayed
            }

            Thread {
                try {
                    val result = callAnthropic(apiKey, snapshot)
                    snapshot.recycle()

                    mainHandler.post {
                        applyResult(result)
                        analysisRunning.set(false)
                    }
                } catch (t: Throwable) {
                    snapshot.recycle()

                    mainHandler.post {
                        signalText.text = "ERREUR"
                        explanationText.text =
                            t.message ?: "Erreur inconnue pendant l'analyse."
                        analysisRunning.set(false)
                    }
                }
            }.start()
        }, 900L)
    }

    private fun scaleBitmap(bitmap: Bitmap, maxDimension: Int = 1568): Bitmap {
        val largest = maxOf(bitmap.width, bitmap.height)
        if (largest <= maxDimension) return bitmap

        val ratio = maxDimension.toFloat() / largest.toFloat()
        val width = (bitmap.width * ratio).roundToInt().coerceAtLeast(1)
        val height = (bitmap.height * ratio).roundToInt().coerceAtLeast(1)

        val scaled = Bitmap.createScaledBitmap(bitmap, width, height, true)
        if (scaled !== bitmap) bitmap.recycle()
        return scaled
    }

    private fun bitmapToBase64Jpeg(bitmap: Bitmap): String {
        val scaled = scaleBitmap(bitmap)
        val output = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 80, output)
        scaled.recycle()
        return Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
    }

    private fun callAnthropic(apiKey: String, bitmap: Bitmap): AnalysisResult {
        val base64 = bitmapToBase64Jpeg(bitmap)

        val prompt = """
            Analyse ce graphique financier.

            Tu dois être prudent : si le graphique est illisible, incomplet ou ambigu,
            réponds ATTENTE. Ne présente jamais une supposition comme une certitude.

            Réponds UNIQUEMENT avec un objet JSON valide, sans markdown :
            {
              "signal":"ACHAT"|"VENTE"|"ATTENTE",
              "confiance":0-100,
              "explication":"1 à 2 phrases courtes en français",
              "stop":"niveau ou condition de stop, sinon \"Non déterminé\"",
              "objectif":"niveau ou condition d'objectif, sinon \"Non déterminé\""
            }

            Le signal est seulement une aide à la lecture graphique, pas une garantie.
        """.trimIndent()

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", MAX_TOKENS)
            .put(
                "messages",
                org.json.JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put(
                            "content",
                            org.json.JSONArray()
                                .put(
                                    JSONObject()
                                        .put("type", "image")
                                        .put(
                                            "source",
                                            JSONObject()
                                                .put("type", "base64")
                                                .put("media_type", "image/jpeg")
                                                .put("data", base64)
                                        )
                                )
                                .put(
                                    JSONObject()
                                        .put("type", "text")
                                        .put("text", prompt)
                                )
                        )
                )
            )

        val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
            setRequestProperty("content-type", "application/json")
            setRequestProperty("accept", "application/json")
        }

        try {
            connection.outputStream.use { output ->
                output.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: ""

            if (code !in 200..299) {
                val compact = responseText.replace(Regex("\\s+"), " ")
                    .take(600)
                throw IllegalStateException("API HTTP $code : $compact")
            }

            return parseAnthropicResponse(responseText)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseAnthropicResponse(response: String): AnalysisResult {
        val root = JSONObject(response)
        val content = root.optJSONArray("content")
            ?: throw IllegalStateException("Réponse API sans contenu.")

        val textParts = StringBuilder()

        for (i in 0 until content.length()) {
            val item = content.optJSONObject(i) ?: continue
            if (item.optString("type") == "text") {
                textParts.append(item.optString("text"))
            }
        }

        val raw = textParts.toString()
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')

        if (start < 0 || end <= start) {
            throw IllegalStateException("Réponse JSON introuvable.")
        }

        val json = JSONObject(raw.substring(start, end + 1))

        val signal = when (json.optString("signal").uppercase()) {
            "ACHAT" -> "ACHAT"
            "VENTE" -> "VENTE"
            else -> "ATTENTE"
        }

        val confidence = json.optInt("confiance", 0).coerceIn(0, 100)
        val explanation = json.optString(
            "explication",
            "Analyse insuffisamment déterminée."
        )
        val stop = json.optString("stop", "Non déterminé")
        val objective = json.optString("objectif", "Non déterminé")

        return AnalysisResult(
            signal = signal,
            confidence = confidence,
            explanation = explanation,
            stop = stop,
            objective = objective
        )
    }

    private fun applyResult(result: AnalysisResult) {
        signalText.text = "${result.signal}  •  ${result.confidence}%"
        explanationText.text =
            "${result.explanation}\nStop : ${result.stop}\nObjectif : ${result.objective}"
    }

    private fun showError(message: String) {
        mainHandler.post {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)

        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {
        }

        try {
            imageReader?.close()
        } catch (_: Throwable) {
        }

        try {
            mediaProjection?.stop()
        } catch (_: Throwable) {
        }

        mediaProjection = null
        virtualDisplay = null
        imageReader = null

        latestBitmap?.recycle()
        latestBitmap = null

        if (::panel.isInitialized) {
            try {
                windowManager.removeView(panel)
            } catch (_: Throwable) {
            }
        }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private data class AnalysisResult(
        val signal: String,
        val confidence: Int,
        val explanation: String,
        val stop: String,
        val objective: String
    )
}
