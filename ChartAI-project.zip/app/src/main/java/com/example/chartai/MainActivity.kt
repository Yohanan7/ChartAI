package com.example.chartai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 1001
        private const val REQUEST_NOTIFICATIONS = 1002
        private const val PREFS_NAME = "chart_ai_prefs"
        private const val KEY_API = "anthropic_api_key"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var apiKeyInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Analyse Graphique"
            textSize = 26f
            setPadding(0, 0, 0, 24)
        }

        val instructions = TextView(this).apply {
            text = """
                Cette application affiche un petit panneau flottant au-dessus de MetaTrader 5.

                1. Entrez votre clé API Anthropic.
                2. Autorisez l'affichage par-dessus les autres applications.
                3. Appuyez sur « Démarrer le pop-up flottant ».
                4. Autorisez la capture d'écran Android.
                5. Dans MT5, appuyez sur « Analyser » pour envoyer le graphique à l'API.

                Utilisez uniquement une clé API que vous contrôlez.
            """.trimIndent()
            textSize = 16f
        }

        apiKeyInput = EditText(this).apply {
            hint = "Clé API Anthropic"
            textSize = 16f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString(KEY_API, ""))
        }

        val startButton = Button(this).apply {
            text = "Démarrer le pop-up flottant"
            setOnClickListener { startFloatingPanel() }
        }

        root.addView(title)
        root.addView(instructions)
        root.addView(apiKeyInput, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 30 })
        root.addView(startButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 20 })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun startFloatingPanel() {
        val apiKey = apiKeyInput.text.toString().trim()
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Entrez votre clé API Anthropic.", Toast.LENGTH_LONG).show()
            return
        }

        prefs.edit().putString(KEY_API, apiKey).apply()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Autorisez « Afficher par-dessus les autres applications », puis relancez.",
                Toast.LENGTH_LONG
            ).show()

            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_NOTIFICATIONS
            )
        }

        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        startActivityForResult(
            projectionManager.createScreenCaptureIntent(),
            REQUEST_MEDIA_PROJECTION
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != REQUEST_MEDIA_PROJECTION) return

        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Capture d'écran refusée.", Toast.LENGTH_LONG).show()
            return
        }

        val serviceIntent = Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(OverlayService.EXTRA_DATA, data)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        moveTaskToBack(true)
    }
}
